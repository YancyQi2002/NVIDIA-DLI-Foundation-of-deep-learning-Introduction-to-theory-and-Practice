<img src="./images/DLI_Header.png" style="width: 400px;">

# 美国手语数据集的图像分类

在本节中，您将使用不同的数据集[American Sign Language](http://www.asl.gs/)中手语字母的图像，执行在上一节中观察到的数据准备、模型创建和模型训练的步骤。

## 目标

在完成本节时，您将能够：
* 准备图像数据进行训练
* 创建并编译用于图像分类的简单模型
* 训练图像分类模型并观察结果

## 手语数据集
我们将使用[美国手语字母表](https://www.kaggle.com/datamunge/sign-language-mnist)图像，该字母表包含 26 个字母。其中有两个字母（j 和 z）涉及一些动作，因此已从本次训练数据集中排除。

<img src="./images/asl.png" style="width: 600px;">

[Kaggle](http://www.kaggle.com) 网站提供了此数据集，此网站内容丰富，您还可在其中查找多个数据集和其他深度学习资源。除了数据集之外，内容贡献者还发布了类似于这些 notebook 的“内核”，并向您展示了如何训练模型和探索数据。如果您正在寻找新的深度学习项目以做入门之用，推荐您访问 Kaggle 网站。该网站还会在其组织的竞赛中附加一些数据集，您可以参与其中，在训练高精度模型方面与他人一较高下。

## 加载数据集

我们将引导您加载ASL数据集，因为它无法像MNIST一样通过Keras获得。在本小节的最后，您将获得您所熟悉的`x_train`，`y_train`，`x_test`和`y_test`变量。

## 读入数据
上一个练习中我们直接从 Keras 内下载数据。与此不同的是，手语数据集采用 CSV 格式。如果您以前使用过电子表格，可能会熟悉 CSV（逗号分隔值）。本质上说，它只是一个由行和列组成的网格，且顶部带有标签。

为加载和处理数据，我们将使用一个名为 Pandas 的库，这是一款可供加载和处理数据的高性能工具。我们将 CSV 文件读入名为 Dataframe 的格式，这是 Pandas 存储数据网格所采用的格式。


```python
import pandas as pd
```

Pandas有一个`read_csv`方法，该方法将读取csv文件，并返回一个数据帧（Dataframe）：


```python
train_df = pd.read_csv("asl_data/sign_mnist_train.csv")
test_df = pd.read_csv("asl_data/sign_mnist_test.csv")
```

### 探索数据

再来观察一下我们的数据。我们可以使用 `head` 函数来抓取数据集的前几行。如您所见，每一行都是一个具有`label`列的图像，还有784个值代表该图像中的每个像素值，就像MNIST数据集一样。请注意，当前标签是数值，而不是字母：


```python
train_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>pixel1</th>
      <th>pixel2</th>
      <th>pixel3</th>
      <th>pixel4</th>
      <th>pixel5</th>
      <th>pixel6</th>
      <th>pixel7</th>
      <th>pixel8</th>
      <th>pixel9</th>
      <th>...</th>
      <th>pixel775</th>
      <th>pixel776</th>
      <th>pixel777</th>
      <th>pixel778</th>
      <th>pixel779</th>
      <th>pixel780</th>
      <th>pixel781</th>
      <th>pixel782</th>
      <th>pixel783</th>
      <th>pixel784</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>107</td>
      <td>118</td>
      <td>127</td>
      <td>134</td>
      <td>139</td>
      <td>143</td>
      <td>146</td>
      <td>150</td>
      <td>153</td>
      <td>...</td>
      <td>207</td>
      <td>207</td>
      <td>207</td>
      <td>207</td>
      <td>206</td>
      <td>206</td>
      <td>206</td>
      <td>204</td>
      <td>203</td>
      <td>202</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6</td>
      <td>155</td>
      <td>157</td>
      <td>156</td>
      <td>156</td>
      <td>156</td>
      <td>157</td>
      <td>156</td>
      <td>158</td>
      <td>158</td>
      <td>...</td>
      <td>69</td>
      <td>149</td>
      <td>128</td>
      <td>87</td>
      <td>94</td>
      <td>163</td>
      <td>175</td>
      <td>103</td>
      <td>135</td>
      <td>149</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>187</td>
      <td>188</td>
      <td>188</td>
      <td>187</td>
      <td>187</td>
      <td>186</td>
      <td>187</td>
      <td>188</td>
      <td>187</td>
      <td>...</td>
      <td>202</td>
      <td>201</td>
      <td>200</td>
      <td>199</td>
      <td>198</td>
      <td>199</td>
      <td>198</td>
      <td>195</td>
      <td>194</td>
      <td>195</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>211</td>
      <td>211</td>
      <td>212</td>
      <td>212</td>
      <td>211</td>
      <td>210</td>
      <td>211</td>
      <td>210</td>
      <td>210</td>
      <td>...</td>
      <td>235</td>
      <td>234</td>
      <td>233</td>
      <td>231</td>
      <td>230</td>
      <td>226</td>
      <td>225</td>
      <td>222</td>
      <td>229</td>
      <td>163</td>
    </tr>
    <tr>
      <th>4</th>
      <td>12</td>
      <td>164</td>
      <td>167</td>
      <td>170</td>
      <td>172</td>
      <td>176</td>
      <td>179</td>
      <td>180</td>
      <td>184</td>
      <td>185</td>
      <td>...</td>
      <td>92</td>
      <td>105</td>
      <td>105</td>
      <td>108</td>
      <td>133</td>
      <td>163</td>
      <td>157</td>
      <td>163</td>
      <td>164</td>
      <td>179</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 785 columns</p>
</div>



### 提取标签

与MNIST一样，我们希望将训练和测试标签存储在`y_train`和`y_test`变量中。 在这里，我们创建这些变量，然后从不再需要它们的原始数据帧中删除标签：


```python
y_train = train_df['label']
y_test = test_df['label']
del train_df['label']
del test_df['label']
```

### 提取图像

与MNIST一样，我们希望将训练和测试图像存储在`x_train`和`x_test`变量中。 我们现在创建这些变量：


```python
x_train = train_df.values
x_test = test_df.values
```

### 总结训练和测试数据

如您所见，我们现在有27,455张784像素的图像用于训练...


```python
x_train.shape
```




    (27455, 784)



...及其相应的标签：


```python
y_train.shape
```




    (27455,)



我们有7,172张图片用于测试...


```python
x_test.shape
```




    (7172, 784)



...及其相应的标签：


```python
y_test.shape
```




    (7172,)



### 数据可视化

为了可视化图像数据，我们将再次使用matplotlib库。您无需担心此可视化的细节，但是如果您愿意，可以稍后再了解有关[matplotlib](https://matplotlib.org/)的更多信息。请注意，我们必须将数据从其当前的784像素的1D形状重构为28x28像素的2D形状才能合理呈现图像：


```python
import matplotlib.pyplot as plt
plt.figure(figsize=(40,40))

num_images = 20
for i in range(num_images):
    row = x_train[i]
    label = y_train[i]
    
    image = row.reshape(28,28)
    plt.subplot(1, num_images, i+1)
    plt.title(label, fontdict={'fontsize': 30})
    plt.axis('off')
    plt.imshow(image, cmap='gray')
```


![png](output_31_0.png)


## 练习：对图像数据进行归一化

正如我们对MNIST数据集所做的那样，我们将对图像数据进行归一化，这意味着它们的像素值将不是介于0到255之间：


```python
x_train.min()
```




    0




```python
x_train.max()
```




    255



...而应为0到1之间的浮点值。请使用以下单元格来完成次项工作。如果卡住了，请查看下面的答案。


```python
# TODO: Normalize x_train and x_test.
x_train = x_train / 255
x_test = x_test / 255
```

### 解答

单击下面的'...'以显示答案。

```python
x_train = x_train / 255
x_test = x_test / 255
```

现在我们可以显示图像了，但我们的标签却是数字的形式，而非以字母表中的字母来表示的。目前这没多大影响，因为我们的模型能够将数字作为预测目标来处理。就像上一个练习一样，我们将采用这些数字并将其转换为由 0 和 1 组成的列表，以便使预测容易一些。

## 练习：标签的分类编码

正如我们对MNIST数据集所做的那样，我们将对标签进行分类编码。回想一下，您可以使用`keras.utils.to_categorical`方法来实现此目的，只需向其传递您希望编码的值，以及您希望的类别数。请在下面的单元格中完成您的工作。我们已导入`keras`并为您设置了类别数（24）。


```python
import tensorflow.keras as keras
num_classes = 24
```


```python
# TODO: Categorically encode y_train and y_test.
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)
```

### 解答

单击下面的'...'以显示答案。

```python
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)
```

## 练习：构建模型

您已经对训练和测试图像进行归一化了，并将训练和测试的标签进行了分类编码。数据已准备就绪。

您将练习构建一个序列化的模型，就像上次建立模型时一样：
* 具有密集输入层。该层应包含512个神经元，使用`relu`激励函数，并期望输入图像的形状为(784，)。
* 具有512个神经元的第二个密集连接层，使用`relu`激励函数。
* 密集输出层，神经元的数量等于类别数，使用`softmax`激励函数。

请在下面的单元格中完成您的工作，创建一个`model`变量来存储您构建的模型。我们已经导入了Keras的`Sequential`模型类和`Dense`层类，以帮助您入门。如果需要帮助，可单击下方的三个点来显示答案。


```python
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
```


```python
# TODO: build a model following the guidelines above.
model = Sequential()
model.add(Dense(units = 512, activation='relu', input_shape=(784,)))
model.add(Dense(units = 512, activation='relu'))
model.add(Dense(units = num_classes, activation='softmax'))
```

### 答案

单击下面的'...'以显示答案。


```python
model = Sequential()
model.add(Dense(units = 512, activation='relu', input_shape=(784,)))
model.add(Dense(units = 512, activation='relu'))
model.add(Dense(units = num_classes, activation='softmax'))
```

## 总结模型

运行下面的单元以显示您刚刚创建的模型的摘要：


```python
model.summary()
```

    Model: "sequential"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    dense (Dense)                (None, 512)               401920    
    _________________________________________________________________
    dense_1 (Dense)              (None, 512)               262656    
    _________________________________________________________________
    dense_2 (Dense)              (None, 24)                12312     
    =================================================================
    Total params: 676,888
    Trainable params: 676,888
    Non-trainable params: 0
    _________________________________________________________________


## 编译模型

我们将使用与之前相同的选项[多分类交叉熵](https://www.tensorflow.org/api_docs/python/tf/keras/losses/CategoricalCrossentropy) 作为损失函数来编译模型，且想要衡量模型的准确率。多分类交叉熵反映出如下事实：我们试图拟合出诸多类别中的一类。


```python
model.compile(loss='categorical_crossentropy', metrics=['accuracy'])
```

注意，编译模型时可以选择不同的`优化器`，上面的编译使用了默认的优化器`RMSProp`。

## 练习：训练模型

使用你的模型的`fit`方法，用您创建的训练和测试图像和标签将模型训练20个周期（epochs）：


```python
# TODO: Train the model for 20 epochs.
model.fit(x_train, y_train,
                    epochs=20,
                    verbose=1,
                    validation_data=(x_test, y_test))
```

    Epoch 1/20
    858/858 [==============================] - 3s 3ms/step - loss: 1.9785 - accuracy: 0.3708 - val_loss: 1.9961 - val_accuracy: 0.4209
    Epoch 2/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.9966 - accuracy: 0.6604 - val_loss: 2.2871 - val_accuracy: 0.4773
    Epoch 3/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.6096 - accuracy: 0.7942 - val_loss: 0.9881 - val_accuracy: 0.6838
    Epoch 4/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.4068 - accuracy: 0.8687 - val_loss: 1.0116 - val_accuracy: 0.7303
    Epoch 5/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.3008 - accuracy: 0.9064 - val_loss: 0.9986 - val_accuracy: 0.7796
    Epoch 6/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.2515 - accuracy: 0.9305 - val_loss: 0.9485 - val_accuracy: 0.7914
    Epoch 7/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.2086 - accuracy: 0.9428 - val_loss: 2.1584 - val_accuracy: 0.6633
    Epoch 8/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.1948 - accuracy: 0.9521 - val_loss: 0.8753 - val_accuracy: 0.8253
    Epoch 9/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.1904 - accuracy: 0.9575 - val_loss: 0.8459 - val_accuracy: 0.8507
    Epoch 10/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.1755 - accuracy: 0.9606 - val_loss: 1.9290 - val_accuracy: 0.7312
    Epoch 11/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.1825 - accuracy: 0.9653 - val_loss: 1.1087 - val_accuracy: 0.8305
    Epoch 12/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.1816 - accuracy: 0.9689 - val_loss: 1.0945 - val_accuracy: 0.8399
    Epoch 13/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.1803 - accuracy: 0.9677 - val_loss: 1.3000 - val_accuracy: 0.8232
    Epoch 14/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.1576 - accuracy: 0.9693 - val_loss: 2.4186 - val_accuracy: 0.7492
    Epoch 15/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.1613 - accuracy: 0.9704 - val_loss: 3.3020 - val_accuracy: 0.6785
    Epoch 16/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.1693 - accuracy: 0.9710 - val_loss: 1.6411 - val_accuracy: 0.7890
    Epoch 17/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.1300 - accuracy: 0.9769 - val_loss: 3.0236 - val_accuracy: 0.7210
    Epoch 18/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.1458 - accuracy: 0.9764 - val_loss: 1.4854 - val_accuracy: 0.8557
    Epoch 19/20
    858/858 [==============================] - 3s 3ms/step - loss: 0.1364 - accuracy: 0.9782 - val_loss: 1.6153 - val_accuracy: 0.8160
    Epoch 20/20
    858/858 [==============================] - 2s 3ms/step - loss: 0.1289 - accuracy: 0.9779 - val_loss: 1.6608 - val_accuracy: 0.8299





    <tensorflow.python.keras.callbacks.History at 0x7f35e46c17b8>



### 答案

单击下面的'...'以显示答案。

```python
model.fit(x_train, y_train,
                    epochs=20,
                    verbose=1,
                    validation_data=(x_test, y_test))
```

## 讨论：发生了什么？
我们可以看到训练集上的准确率已经相当高，但验证准确率却没有那么高。您认为此处发生了什么？先思考片刻再查看下一部分的内容。

这是一个典型的例子，即模型学习了对训练集里的数据进行分类，但对于尚未采用的新数据进行分类的表现却并不理想。从本质上讲，这是由于模型只是在训练中记忆数据，而非真正获得对该问题（数据分类）的理解。这是一个常见的问题，称为过拟合。在接下来的两个讲座中，我们将讨论过拟合以及解决此问题的一些方法。

## 总结

在本节中，您构建了自己的神经网络来执行图像分类。尽管还有改进的余地（我们很快会讲如何改进），但您做得不错。 恭喜！

到这里为止，您应该对加载数据（包括标签）、准备数据、创建模型以及使用准备好的数据训练模型的过程有所了解了。

### 清理显存
在进入下一节内容前，请先执行以下单元，以清理 GPU 显存。转至下一 notebook 之前需要执行此操作。


```python
import IPython
app = IPython.Application.instance()
app.kernel.do_shutdown(True)
```




    {'status': 'ok', 'restart': True}



## 下一步

现在，您已经建立了几个虽然基本但还是有效的模型，您将开始学习更复杂的模型，包括*卷积神经网络*。

请继续下一节：[*使用CNN的ASL*](./03_asl_cnn.ipynb)。
